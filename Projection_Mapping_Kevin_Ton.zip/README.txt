**************************************************************************************************************************
	Author: Kevin Ton,
	Project: OpenFrameWorks Projection Mapping
	Filename: README.txt
**************************************************************************************************************************
LIST OF FILES:

Code Repository:
CurvedBalls.h
MucusCells.cpp
MucusCells.h
ofApp.cpp
ofApp.h
PlanetOrbit.cpp
PlanetOrbit.h
WebLights.h
main.cpp


File Repository:
README.txt


**************************************************************************************************************************
COMPILE INSTRUCTIONS:
In directory, type "make"
**************************************************************************************************************************
OPERATION INSTRUCTIONS:
	Run main.cpp through openFrameWorks
**************************************************************************************************************************
List/description of any extra features/algorithms/functionality you included which were not 
required:
N/A
**************************************************************************************************************************
LIST/DESCRIPTION OF ALL KNOWN DEFICIENCIES OR BUGS
N/A
**************************************************************************************************************************
LESSONS LEARNED: 
Worked with various different projection mapping techniques to display on
any object in real time using a raspberry pi
**************************************************************************************************************************